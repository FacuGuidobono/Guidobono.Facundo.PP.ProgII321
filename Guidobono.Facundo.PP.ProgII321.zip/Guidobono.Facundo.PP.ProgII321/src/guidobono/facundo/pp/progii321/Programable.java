package guidobono.facundo.pp.progii321;


public interface Programable {
    
    String programar();
    
}
