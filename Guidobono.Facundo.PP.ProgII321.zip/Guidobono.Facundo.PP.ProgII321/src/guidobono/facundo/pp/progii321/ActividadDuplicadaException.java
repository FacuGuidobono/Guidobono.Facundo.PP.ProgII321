
package guidobono.facundo.pp.progii321;


/**
 * excepcion para el caso en que se intenta
 * agregar una actividad a un centro de entrenamiento que ya existe
 * se puede pasar un mensaje personalizado o usar el mensaje por default.
 * @author facun
 */



public class ActividadDuplicadaException extends Exception {
    
    private static final String MESSAGE = "LA ACTIVIDAD ESTA DUPLICADA";
    
    public ActividadDuplicadaException() {
        this(MESSAGE);
    }

    public ActividadDuplicadaException(String message) {
        super(message);
    }
    
    
    
}
