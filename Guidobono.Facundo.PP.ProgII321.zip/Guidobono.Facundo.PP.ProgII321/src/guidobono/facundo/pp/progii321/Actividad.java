package guidobono.facundo.pp.progii321;

import java.util.Objects;


public abstract class Actividad {
    
    private final String nombre;
    private final String entrenador;
    private final NivelIntensidad nivel;

    public Actividad(String nombre, String entrenador, NivelIntensidad nivel) {
        validarNombre(nombre,"El nombre de la actividad no puede estar vacio o ser nulo.");
        validarNombre(entrenador,"El nombre del entrenador no puede estar vacio o ser nulo.");
        validarNivelIntensidad(nivel);
        this.nombre = nombre;
        this.entrenador = entrenador;
        this.nivel = nivel;
    }
    
    
    private void validarNombre(String nombre, String message){
        if (nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException(message);
            }
    }
    
    private void validarNivelIntensidad(NivelIntensidad nivel){
            if (nivel == null){
                throw new IllegalArgumentException("El nivel de intensidad no puede ser nulo.");
            }
    }
    
    public String getNombre(){ 
        return nombre;
    }
    
    public String getEntrenador(){
        return entrenador;
    }

    public NivelIntensidad getNivelIntensidad(){
           return nivel;
    }

    
    @Override
    public boolean equals(Object o){
        if (this == o){
            return true;  
        }
        if (!(o instanceof Actividad actividadParaComparar)){
            return false;
        }
        
        return nombre.equals(actividadParaComparar.nombre)  && entrenador.equals(actividadParaComparar.entrenador);
        
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre,entrenador);
    }
    
    public abstract String getDescripcion();
    
    @Override
    public String toString() {
        return this.getClass().getSimpleName() + getDescripcion();
    }
       
}
