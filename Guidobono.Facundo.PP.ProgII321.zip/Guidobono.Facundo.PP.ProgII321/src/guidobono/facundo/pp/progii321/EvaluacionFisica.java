package guidobono.facundo.pp.progii321;


public class EvaluacionFisica extends Actividad implements Informable {
    private final int puntaje;
    private static final int PUNTAJEMIN = 0;
    private static final int PUNTAJEMAX = 100;

    
    public EvaluacionFisica(String nombre, String entrenador, NivelIntensidad nivel, int puntaje) {
        super(nombre, entrenador, nivel);
        validarPuntaje(puntaje);
        this.puntaje = puntaje;
    }
   
    
    private void validarPuntaje(int puntaje){       
        if(puntaje < PUNTAJEMIN || puntaje > PUNTAJEMAX){
               throw new IllegalArgumentException("El puntaje debe comprender numeros entre " + PUNTAJEMIN + "y" + PUNTAJEMAX);
        }
    }

    public int getPuntaje(){
        return puntaje;
    }
    
    /**
     * muestra una descripcion de la evaluacion fisica
     * @return los datos de importancia de la evaluacion fisica
     */
    
    @Override
    public String getDescripcion() {
        return " [nombre=" + getNombre() + ", entrenador=" +  getEntrenador() 
                + ", intensidad=" +  getNivelIntensidad() + ", puntaje=" + getPuntaje() + "]";
    }

    /**
     * genera un informe especifico para una evaluacion fisica
     * @return los valores especificos de una instacia de evaluacion fisica.
     */
    
    @Override
    public String generarInforme() {
       return "Informe de evaluacion fisica: " + getNombre() 
               + ". Puntaje obtenido: " + getPuntaje() + "/" + PUNTAJEMAX + ".";
    }
   

    
}
