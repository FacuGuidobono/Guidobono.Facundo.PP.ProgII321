package guidobono.facundo.pp.progii321;


public interface Informable {
    
    String generarInforme();
    
}
