package guidobono.facundo.pp.progii321;

import java.util.ArrayList;
import java.util.List;

/**
  clase que simula un centro de entrenamiento, gestiona diversas actividades.
 
 */




public class CentroEntrenamiento {
    /**
     * @param nombre: String , nombre del centro de entrenamiento
     * @param actividades: List<Actividades> , son las actividades que gestiona el centro.
     */
    
    private final String nombre;
    private final List <Actividad> actividades;

    public CentroEntrenamiento(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        actividades = new ArrayList<>();
    }
    
    
    private void validarNombre(String nombre){
        if (nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("El nombre del centro de entrenamiento no puede estar vacio.");
            }
    
    }
    
     private void validarActividad(Actividad a){
        if (a == null){
              throw new NullPointerException("No se puede agregar actividades nulas");
        }
    
     }
        
    private void validarActividadRepetida(Actividad a)throws ActividadDuplicadaException{
        
        if (actividades.contains(a)) {
            throw new ActividadDuplicadaException(
            "Ya existe una actividad con nombre " 
             +"'"+ a.getNombre() +"'"
             + " Y entrenador " +"'"+ a.getEntrenador()+"'."
            );
        }
    }
    
     /** 
     * el metodo agregarActividad() agrega actividades al centro
     * @param a es la actividad que se desea agregar al centro de entrenamiento
     * @throws ActividadDuplicadaException se lanza si la actividad ya se encuentra en el centro
     * 
    **/
    
    public void agregarActividad(Actividad a) throws ActividadDuplicadaException {
        validarActividad(a);
        validarActividadRepetida(a);
        actividades.add(a);
    }
    
    
    public List<Actividad> obtenerActividades(){
        return new ArrayList<>(actividades);   
    }
    
    private void validarNivelIntencidad(NivelIntensidad nivel){
            if (nivel == null){
                throw new IllegalArgumentException("El nivel de intensidad no puede ser nulo.");
            }
    }
    
    
    /**
     * filtra las actividades del centro de entrenamientos por nivel de intensidad
     * @param nivel es el nivel de las actividades que se desea filtrar
     * @return actividadesFiltradas. retorna las actividades filtradas
     */
    
    public List<Actividad> filtrarPorNivel(NivelIntensidad nivel){
        validarNivelIntencidad(nivel);
        List<Actividad> actividadesFiltradas = new ArrayList<>();
        
        for (Actividad a : actividades ){
            if (a.getNivelIntensidad() == nivel){
                actividadesFiltradas.add(a);
            }
        }
        return actividadesFiltradas;
    }
    
  
    public String getNombre(){
            return nombre;
    }
    
    
}
