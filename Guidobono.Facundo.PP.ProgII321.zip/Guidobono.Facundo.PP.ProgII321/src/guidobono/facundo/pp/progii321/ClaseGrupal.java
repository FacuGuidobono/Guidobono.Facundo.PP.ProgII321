
package guidobono.facundo.pp.progii321;

/**
 * Actividad del tipo clase grupal que es programable
 */
public class ClaseGrupal extends Actividad implements Programable{
    private final int maxParticipantes;

    public ClaseGrupal(String nombre, String entrenador, NivelIntensidad nivelintensidad, int maxParticipantes) {
        super(nombre, entrenador, nivelintensidad);
        validarMaxParticipantes(maxParticipantes);
        this.maxParticipantes = maxParticipantes;
    }
        
    
    private void validarMaxParticipantes(int MaxParticipantes){
        if(MaxParticipantes <= 0){
            throw new IllegalArgumentException("La cantidad maxima de participantes no puede ser 0 o menor a 0.");
        }
    }
    
    
    public int getMaxParticipantes(){
        return maxParticipantes;
    }
    
    
    /**
     * muestra una descripcion de una clase grupal
     * @return los datos de importancia de una clase grupal
     */
    
    @Override
    public String getDescripcion() {
       return " [nombre=" + getNombre() + ", entrenador=" +  getEntrenador() 
                + ", intensidad=" +  getNivelIntensidad() 
               + ", MaxParticipantes=" + getMaxParticipantes()+ "]";
    }
    
    
    /**
     * programa una clase grupal
     * @return el nombre de la clase grupal que se programo.
     */
    
    @Override
    public String programar() {
        return "Se programo la clase grupal: " + getNombre();
    }
    
}
