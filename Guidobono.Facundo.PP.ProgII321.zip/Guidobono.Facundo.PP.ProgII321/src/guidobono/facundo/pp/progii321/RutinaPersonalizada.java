
package guidobono.facundo.pp.progii321;


public class RutinaPersonalizada extends Actividad implements Informable,Programable{
    
    private final int duracionSemanas;

    public RutinaPersonalizada(String nombre, String entrenador, NivelIntensidad nivelintensidad, int duracionSemanas) {
        super(nombre, entrenador, nivelintensidad);
        validarDuracionSemanas(duracionSemanas);
        this.duracionSemanas = duracionSemanas;
    }
    
    
    private void validarDuracionSemanas(int duracionSemanas){
        if(duracionSemanas <= 0){
            throw new IllegalArgumentException("La duracion de las semanas ni puede ser 0 ni menor a 0.");
        }
    }
    
    
    public int getDuracionSemanas(){
        return duracionSemanas;
    }
    
   
    
    /**
     * muestra una descripcion de una rutina personalizada
     * @return los datos de importancia de una rutina personalizada
     */
    
    
    @Override
    public String getDescripcion() {
        return " [nombre=" + getNombre() + ", entrenador=" +  getEntrenador() 
                + ", intensidad=" +  getNivelIntensidad() 
               + ", duracionSemanas=" + getDuracionSemanas()+ "]";
    }
    
    /*
     * genera un informe especifico para una rutina personalizada
     * @return los valores especificos de una instacia de rutina personalizada.
     */
    
    @Override
    public String generarInforme() {
       return "Informe de rutina personalizada: " + getNombre() 
               + ". Duracion estimada: " + getDuracionSemanas() + " semanas.";
    }
    
    /**
     * programa una rutina personalizada
     * @return el nombre de la rutina que se programo.
     */
    
    @Override
    public String programar() {
        return "Se programo la rutina personalizada: " + getNombre();
    }
    
}
