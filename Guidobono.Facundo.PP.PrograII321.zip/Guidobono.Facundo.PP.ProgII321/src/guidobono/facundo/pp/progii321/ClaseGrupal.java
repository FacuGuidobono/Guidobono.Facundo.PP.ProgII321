
package guidobono.facundo.pp.progii321;

/**
 *
 */
public class ClaseGrupal extends Actividad{
    private int maxParticipantes;

    public ClaseGrupal(String nombre, String entrenador, NivelIntensidad nivelintensidad, int maxParticipantes) {
        super(nombre, entrenador, nivelintensidad);
        this.maxParticipantes = maxParticipantes;
    }
        
        
    
}
