
package guidobono.facundo.pp.progii321;


public class ActividadDuplicadaException extends Exception {
    
    private static final String MESSAGE = "ACTIVIDAD DUPLICADA DEFAULT";
    public ActividadDuplicadaException() {
        this(MESSAGE);
    }

    public ActividadDuplicadaException(String message) {
        super(message);
    }
    
    
    
}
