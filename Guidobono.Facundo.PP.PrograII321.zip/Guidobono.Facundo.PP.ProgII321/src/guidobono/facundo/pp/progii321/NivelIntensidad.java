package guidobono.facundo.pp.progii321;

/**
  Niveles de intensidad que pueden tener cada actividad
 
 */

public enum NivelIntensidad {
    BAJA,
    MEDIA,
    ALTA;
}
