/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.pp.progii321;

/**
 *
 * @author facun
 */
public class RutinaPersonalizada extends Actividad{
    
    private int duracionSemanas;

    public RutinaPersonalizada(String nombre, String entrenador, NivelIntensidad nivelintensidad, int duracionSemanas) {
        super(nombre, entrenador, nivelintensidad);
        this.duracionSemanas = duracionSemanas;
    }
    
}
