package guidobono.facundo.pp.progii321;

import java.util.ArrayList;

/**
  clase que simula un centro de entrenamiento, gestiona diversas actividades.
 
 */




public class CentroEntrenamiento {
    /**
     * @param nombre: String , nombre del centro de entrenamiento
     * @param actividades: ArrayList<Actividades> , son las actividades que gestiona el centro.
     */
    
    private final String nombre;
    private final ArrayList <Actividad> actividades = new ArrayList<>();

    public CentroEntrenamiento(String nombre) {
        this.nombre = nombre;
    }
    
    
    public void agregarActividad(Actividad a) throws ActividadDuplicadaException{
        
        if (a == null){
              throw new NullPointerException("No se puede agregar actividades nulas");
        }
        
        if (actividades.contains(a)) {
            throw new ActividadDuplicadaException();
        }
        
         actividades.add(a);
    }
    
    
    public ArrayList<Actividad> obtenerActividades(){
        //falta implementacion
        return actividades;
        
    }
    
    
    public ArrayList<Actividad> filtrarPorNivel(NivelIntensidad ne){
        return actividades;
    }
    
}
