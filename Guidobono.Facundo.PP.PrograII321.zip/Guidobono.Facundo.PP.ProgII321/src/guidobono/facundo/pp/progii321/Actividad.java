package guidobono.facundo.pp.progii321;


public abstract class Actividad {
    
    private String nombre;
    private String entrenador;
    private NivelIntensidad nivelintensidad;

    public Actividad(String nombre, String entrenador, NivelIntensidad nivelintensidad) {
        this.nombre = nombre;
        this.entrenador = entrenador;
        this.nivelintensidad = nivelintensidad;
    }
    
    
    public String getNombre(){
        
        return nombre;
    
    }
    
    public String getEntrenador(){
        return entrenador;
    }

    
}
