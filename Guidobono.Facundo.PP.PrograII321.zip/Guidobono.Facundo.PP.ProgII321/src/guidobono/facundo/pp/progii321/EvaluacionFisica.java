/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.pp.progii321;


public class EvaluacionFisica extends Actividad {
    private int puntaje;
    private static final int PUNTAJEMAX = 100;

    public EvaluacionFisica(String nombre, String entrenador, NivelIntensidad nivelintensidad, int puntaje) {
        super(nombre, entrenador, nivelintensidad);
        validarPuntaje(puntaje);
    }
   
    
    private void validarPuntaje(int puntaje){       
        if(puntaje < 0 || puntaje > PUNTAJEMAX){
               throw new IllegalArgumentException("El puntaje debe comprender numeros entre 0 y 100");
        }
        this.puntaje = puntaje;
    
    }
    
    
    
}
