
package guidobono.facundo.recpp.progii321;

/**
 * nivel de clasificacion de los archivos
 * 
 */
public enum NivelClasificacion {
     PUBLICO, 
     RESERVADO,
     ULTRASECRETO;
}
