
package guidobono.facundo.recpp.progii321;

import java.util.ArrayList;
import java.util.List;


public class ArchivoDesclasificado {
    private final String nombre;
    private final List <ArchivoExtraterrestre> archivos;
    
    
    public ArchivoDesclasificado(String nombre){
        validarNombre(nombre);
        this.nombre = nombre;
        archivos = new ArrayList<>();
    }
   
    private void validarNombre(String nombre){
        if (nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("El nombre del Archivo Desclasificado no puede estar en blanco.");
            }
    }
    
    
    
    
    private void validarArchivo(ArchivoExtraterrestre d){
        if (d == null){
              throw new NullPointerException("No se puede agregar archivos nulos");
        }
    
     }
    
    
    
    private void validarArchivoRepetido(ArchivoExtraterrestre d )throws ArchivoDuplicadoException{
        
        if (archivos.contains(d)) {
            throw new ArchivoDuplicadoException(
            "Ya existe un archivo con codigo" 
             +"'"+ d.getCodigo() +"'"
             + " perteneciente a la agencia " +"'"+ d.getAgencia()+"'."
            );
        }
    }
    
    
    private void validarNivelClasificacion(NivelClasificacion nivel){
            if (nivel == null){
                throw new IllegalArgumentException("El nivel de clasificacion no puede ser nulo.");
            }
    }
     /** 
     * el metodo agregarArchivo() agrega archivos clasificados
     * @param d es el documento (archivo) que se desea agregar a archivos desclasificados
     * @throws ArchivoDuplicadoException se lanza si la archivo ya se encuentra desclasificado
     * 
    **/
    
    public void agregarArchivo(ArchivoExtraterrestre d) throws  ArchivoDuplicadoException{
        validarArchivo(d);
        validarArchivoRepetido(d);
        archivos.add(d);
    }
    
    
    public List<ArchivoExtraterrestre> obtenerArchivos(){
        return new ArrayList<>(archivos);   
    }
    
    
    
    /**
     * filtrarPorClasificacion() filtra archivos por un nivel determinado 
     * @param nivel es el nivel por el cual se desea filtrar archivos
     * @return una lista de archivos filtrados por el nivel seleccionado
     */
    
    
    public List<ArchivoExtraterrestre> filtrarPorClasificacion(NivelClasificacion nivel){
        validarNivelClasificacion(nivel);
        
        List<ArchivoExtraterrestre> ArchivosFiltrados = new ArrayList<>();
        
        for (ArchivoExtraterrestre d : archivos ){
            if (d.getNivelClasifiacion()== nivel){
                ArchivosFiltrados.add(d);
            }
        }
        return ArchivosFiltrados;
    }
    
    
    
}
