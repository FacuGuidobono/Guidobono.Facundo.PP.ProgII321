/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.recpp.progii321;

/**
 *
 * @author facun
 */
public class EvidenciaTecnica extends ArchivoExtraterrestre{
    private final int nivel;
    private static final int NIVEL_MIN = 0;
    private static final int NIVEL_MAX = 100;
    private final String fecha;
    
   public EvidenciaTecnica(String codigo, String agencia, NivelClasificacion clasificacion, String fecha, int nivel){
        super(codigo,agencia,clasificacion);
        validarNivel(nivel);
        validarFecha(fecha, "La fecha ingresada no puede estar vacio o ser nulo.");
        this.nivel = nivel;
        this.fecha = fecha;
   }
   
   private void validarNivel(int nivel){       
        if(nivel < NIVEL_MIN|| nivel > NIVEL_MAX){
               throw new IllegalArgumentException("El nivel de confiabilidad debe estar entre " + NIVEL_MIN + "y" + NIVEL_MAX);
        }
    }
   
    private void validarFecha(String s, String message){
        if (s == null || s.isBlank()){
            throw new IllegalArgumentException(message);
            }
    }
    
   
}
