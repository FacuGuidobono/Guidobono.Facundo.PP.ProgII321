/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.recpp.progii321;

/**
 *
 * @author facun
 */
public class TestimonioClasificado extends ArchivoExtraterrestre implements Informable{
    
    private final String testigo;
    
    
    public TestimonioClasificado(String codigo, String agencia, NivelClasificacion nivel, String testigo) {
        super(codigo, agencia, nivel);
        validarTestigo(testigo, "El alias del testigo no puede estar vacio o ser nulo.");
        this.testigo = testigo;
        
    }
    
    
    private void validarTestigo(String s, String message){
        if (s == null || s.isBlank()){
            throw new IllegalArgumentException(message);
            }
    }

    @Override
    public String generarInforme() {
        
        return null;
        
    }
    
    
}
