
package guidobono.facundo.recpp.progii321;

 /**
 * excepcion para el caso en que se intenta
 * agregar un archivo a un que ya existe
 * se puede pasar un mensaje personalizado o usar el mensaje por default.
 */

public class ArchivoDuplicadoException extends Exception {

    
    private static final String MESSAGE = "EL ARCHIVO ESTA DUPLICADO";
    
    public ArchivoDuplicadoException() {
        this(MESSAGE);
    }

    public ArchivoDuplicadoException(String message) {
        super(message);
    }
}
