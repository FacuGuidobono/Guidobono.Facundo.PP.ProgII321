package guidobono.facundo.recpp.progii321;

import java.util.Objects;


public class ArchivoExtraterrestre {
    
    private final String codigo;
    private final String agencia;
    private final NivelClasificacion nivel;
    
    
   
    public ArchivoExtraterrestre(String codigo, String agencia, NivelClasificacion nivel) {
        validarString(codigo, "El codigo ingresado no puede estar vacio o ser nulo.");
        validarString(agencia,  "La agencia ingresada no puede estar vacia o ser nulo.");
        
        this.codigo = codigo;
        this.agencia = agencia;
        this.nivel = nivel;
    }
    
    
    private void validarString(String s, String message){
        if (s == null || s.isBlank()){
            throw new IllegalArgumentException(message);
            }
    }
    
    public String getCodigo(){
      return codigo;
    }
    
    
    public String getAgencia(){
        return agencia;
    }
    
    
    public NivelClasificacion getNivelClasifiacion(){
        return nivel;
    }
    
    
    @Override
    public boolean equals(Object o){
        if (this == o){
            return true;  
        }
        if (!(o instanceof ArchivoExtraterrestre archivoParaComparar)){
            return false;
        }
        
        return codigo.equals(archivoParaComparar.codigo)  && agencia.equals(archivoParaComparar.agencia);
        
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo,agencia);
    }
    
    
}
