/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package guidobono.facundo.recpp.progii321;

/**
 *
 * @author facun
 */
public interface Informable {
    
    String generarInforme();
    
}
