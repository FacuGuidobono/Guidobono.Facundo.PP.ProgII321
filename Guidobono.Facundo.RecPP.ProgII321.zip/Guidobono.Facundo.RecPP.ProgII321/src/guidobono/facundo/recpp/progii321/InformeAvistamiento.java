/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.recpp.progii321;

/**
 *
 * @author facun
 */
public class InformeAvistamiento extends EvidenciaTecnica implements Analizable{
    private final String ubicacion;
    
    
    public InformeAvistamiento(String codigo, String agencia, NivelClasificacion clasificacion, String fecha, int nivel, String ubicacion ){
            super(codigo,agencia,clasificacion,fecha,nivel);
            validarUbicacion(ubicacion, "La ubicacion del fenomeno ingresada no puede estar vacia o ser nula.");
            this.ubicacion = ubicacion;
    
    }
    
    private void validarUbicacion(String ubicacion, String message){
        if (ubicacion == null || ubicacion.isBlank()){
            throw new IllegalArgumentException(message);
            }
    }

    @Override
    public String analizar() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    

    
    
    
    
}
