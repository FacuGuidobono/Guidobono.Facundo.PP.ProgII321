/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guidobono.facundo.recpp.progii321;

/**
 *
 * @author facun
 */
public class RegistroSensor extends EvidenciaTecnica implements Analizable{
    
    private final double frecuencia;
    
    
    public RegistroSensor(String codigo, String agencia, NivelClasificacion clasificacion, String fecha, int nivel, double frecuencia) {
        super(codigo, agencia, clasificacion, fecha, nivel);
        validarFrecuancia(nivel);
        this.frecuencia = frecuencia;
    }
    
    private void validarFrecuancia(int frecuencia){       
        if(frecuencia < 0){
               throw new IllegalArgumentException("El nivel de frecuencia debe ser mayor o igual a 0");
        }
    }

   @Override
    public String analizar() {
        return "Se analizo la evidencia" + super.getCodigo() +   "con un nivel de confiabilidad de"  ;
    }
    
    
    
}
